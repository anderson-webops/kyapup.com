# Encode URL

[![NPM Version][npm-image]][npm-url]
[![NPM Downloads][downloads-image]][downloads-url]
[![Build Status][ci-image]][ci-url]
[![Test Coverage][coverage-image]][coverage-url]

Encode a URL to a percent-encoded form, excluding already-encoded sequences.

## Installation

```sh
npm install encodeurl
```

## API

```js
import { encodeUrl } from "encodeurl";
```

Requires Node.js 22 or later. TypeScript declarations are included.

### encodeUrl(url)

Encode a URL to a percent-encoded form, excluding already-encoded sequences.

This function accepts a URL and encodes all the non-URL code points (as UTF-8 byte sequences). It will not encode the "%" character unless it is not part of a valid sequence (`%20` will be left as-is, but `%foo` will be encoded as `%25foo`).

This encode is meant to be "safe" and does not throw errors. It will try as hard as it can to properly encode the given URL, including replacing any raw, unpaired surrogate pairs with the Unicode replacement character prior to encoding.

## Examples

### Encode a URL containing user-controlled data

```js
import { encodeUrl } from "encodeurl";
import escapeHtml from "escape-html";

http.createServer(function onRequest(req, res) {
  // get encoded form of inbound url
  var url = encodeUrl(req.url);

  // create html message
  var body = "<p>Location " + escapeHtml(url) + " not found</p>";

  // send a 404
  res.statusCode = 404;
  res.setHeader("Content-Type", "text/html; charset=UTF-8");
  res.setHeader("Content-Length", String(Buffer.byteLength(body, "utf-8")));
  res.end(body, "utf-8");
});
```

### Encode a URL for use in a header field

```js
import { encodeUrl } from "encodeurl";
import escapeHtml from "escape-html";
import * as url from "node:url";

http.createServer(function onRequest(req, res) {
  // parse inbound url
  var href = url.parse(req);

  // set new host for redirect
  href.host = "localhost";
  href.protocol = "https:";
  href.slashes = true;

  // create location header
  var location = encodeUrl(url.format(href));

  // create html message
  var body = "<p>Redirecting to new site: " + escapeHtml(location) + "</p>";

  // send a 301
  res.statusCode = 301;
  res.setHeader("Content-Type", "text/html; charset=UTF-8");
  res.setHeader("Content-Length", String(Buffer.byteLength(body, "utf-8")));
  res.setHeader("Location", location);
  res.end(body, "utf-8");
});
```

## Similarities

This function is _similar_ to the intrinsic function `encodeURI`. However, it will not encode:

- The `\`, `^`, or `|` characters
- The `%` character when it's part of a valid sequence
- `[` and `]` (for IPv6 hostnames)
- Replaces raw, unpaired surrogate pairs with the Unicode replacement character

As a result, the encoding aligns closely with the behavior in the [WHATWG URL specification][whatwg-url]. However, this package only encodes strings and does not do any URL parsing or formatting.

It is expected that any output from `new URL(url)` will not change when used with this package, as the output has already been encoded. Additionally, if we were to encode before `new URL(url)`, we do not expect the before and after encoded formats to be parsed any differently.

## Testing

```sh
$ npm install
$ npm test
$ npm run build
```

## References

- [RFC 3986: Uniform Resource Identifier (URI): Generic Syntax][rfc-3986]
- [WHATWG URL Living Standard][whatwg-url]

[rfc-3986]: https://tools.ietf.org/html/rfc3986
[whatwg-url]: https://url.spec.whatwg.org/

## License

[MIT](LICENSE)

[npm-image]: https://img.shields.io/npm/v/encodeurl
[npm-url]: https://npmjs.org/package/encodeurl
[downloads-image]: https://img.shields.io/npm/dm/encodeurl
[downloads-url]: https://npmcharts.com/compare/encodeurl?minimal=true
[ci-image]: https://img.shields.io/github/actions/workflow/status/pillarjs/encodeurl/ci.yml?branch=master
[ci-url]: https://github.com/pillarjs/encodeurl/actions/workflows/ci.yml
[coverage-image]: https://img.shields.io/codecov/c/github/pillarjs/encodeurl/master
[coverage-url]: https://codecov.io/gh/pillarjs/encodeurl
