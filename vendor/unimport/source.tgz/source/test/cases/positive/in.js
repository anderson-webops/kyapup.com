Foo instanceof Bar
