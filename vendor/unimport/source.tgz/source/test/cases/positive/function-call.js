useFoo(ref, 1)
