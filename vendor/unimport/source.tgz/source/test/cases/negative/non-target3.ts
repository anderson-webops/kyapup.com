obj.fit()

