import { $ } from 'jquery';
$('hi')
