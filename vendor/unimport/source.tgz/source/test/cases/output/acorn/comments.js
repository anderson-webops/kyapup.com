import { ref, computed, toRefs } from 'vue';
import { useEffect } from 'react';
/* import { ref } from 'vue' */
// import { computed } from 'vue'

const a = {
  rel: "noreferrer",
  href: "https://github.com/antfu/vitesse",
  target: "_blank"
}

const foo = ref(0)
const bar = computed(() => {})

const b = { class: "text-sm opacity-75" };
const templateLiteralWithDoubleSlash = `http://${useEffect()}`
const templateLiteralWithPseudoComment = `/* ${toRefs()} */`
// reactive
//reactive
/*reactive*/
/**/
