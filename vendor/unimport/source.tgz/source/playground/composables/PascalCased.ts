export class PascalCased {
}
