export const runtimeDependencies = [
  // other deps
  'devalue',
  'klona',
  'unhead',
  // deliberate exports from nitro builder
  '@nuxt/nitro-server/h3',
  // unjs ecosystem
  'defu',
  'ufo',
  'destr',
  'consola',
  'hookable',
  'unctx',
  'cookie-es',
  'perfect-debounce',
  'fnv1a-64',
  'object-identity',
  'ohash',
  'pathe',
  'uncrypto',
]
