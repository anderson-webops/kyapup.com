# Visit [documentation](https://vite-plugin-checker.netlify.app) for usage

A Vite plugin that can run TypeScript, vue-tsc, ESLint, Biome, Stylelint in worker thread.

<p align="center">
  <img alt="screenshot" src="https://user-images.githubusercontent.com/12322740/152739742-7444ee62-9ca7-4379-8f02-495c612ecc5c.png">
</p>

## Online playground

| Examples           | StackBlitz                                                       |
| ------------------ | ---------------------------------------------------------------- |
| Vue3 + vue-tsc     | [⚡️ StackBlitz](https://stackblitz.com/edit/vitejs-vite-e8pddl) |
| React + TypeScript | [⚡️ StackBlitz](https://stackblitz.com/edit/vitejs-vite-b4zcev) |
| ESLint             | [⚡️ StackBlitz](https://stackblitz.com/edit/vitejs-vite-l1ritu) |
| Multiple           | [⚡️ StackBlitz](https://stackblitz.com/edit/vitejs-vite-mb4ea6) |

## License

MIT License © 2022 [fi3ework](https://github.com/fi3ework)
